#include "../basil.js";
#include "../lib/basil.test.js";

#include "typography-tests.jsx";
#include "transform-tests.jsx";
#include "conversion-tests.jsx";
#include "data-tests.jsx";
#include "environment-tests.jsx";
#include "input-tests.jsx";
#include "math-tests.jsx";
#include "string-tests.jsx";
#include "color-tests.jsx";
#include "vertex-tests.jsx";
#include "group-tests.jsx";